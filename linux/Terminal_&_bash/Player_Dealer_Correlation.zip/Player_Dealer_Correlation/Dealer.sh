#!/bin/bash

if [ $1 = "roulette" ]
then
 cat ${2}_Dealer_schedule | awk -F" " '{print $1,$2,$5,$6}' | grep "${3}" 
fi

if [ $1 = "BlackJack" ] 
then
 cat ${2}_Dealer_schedule | awk -F" " '{print $1,$2,$3,$4}' | grep "${3}" 
fi

if [ $1 = "Texas_Hold_EM" ] 
then
 cat ${2}_Dealer_schedule | awk -F" " '{print $1,$2,$7,$8}' | grep "${3}" 
fi


